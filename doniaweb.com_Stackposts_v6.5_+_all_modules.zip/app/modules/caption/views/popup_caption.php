<div class="load-caption">
    <div class="card-header">
        <div class="card-title">
            <i class="ft-command" style="font-size: 16px;" aria-hidden="true"></i> <?=lang('caption')?>
            <div class="pull-right">
                <a class="caption-close"><i class="ft-x"></i></a>
            </div>
        </div>
    </div>
    <div class="caption-body caption-scrollbar scrollbar scrollbar-dynamic"></div>
</div>