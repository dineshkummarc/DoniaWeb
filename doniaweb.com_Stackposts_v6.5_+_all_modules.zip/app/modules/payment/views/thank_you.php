<div class="section-tk">
    <div class="text-center">
        <div class="icon success"><i class="fa fa-check-circle" aria-hidden="true"></i></div>
        <p class="title"><?=lang('you_are_all_set')?>!</p>
        <p class="desc"><?=lang('thank_you_for_being_awesome')?>, <br><?=lang('we_hope_you_enjoy_your_purchase')?>!</p>
        <p class="sign"><strong> <?=lang('website_name')?></strong>, <i><?=lang('marketting_tools')?></i></p>
        <a href="<?=cn('dashboard')?>" class="btn btn-success btn-lg"> <?=lang('go_to_dashboard')?></a>
    </div>
</div>