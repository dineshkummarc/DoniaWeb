<li class="nav-item <?=(segment(1) == 'coupon')?"active":""?>">
    <a href="<?=cn("coupon")?>">
        <i class="ft-percent" aria-hidden="true" data-toggle="tooltip" data-placement="right" title="<?=lang('Coupon manager')?>"></i>
        <span class="name"> <?=lang('Coupon manager')?></span>
    </a>
</li>