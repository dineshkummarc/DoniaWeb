<div class="ig-analytics" id="box-analytics" style="margin-top: 125px;">
	<div class="container text-center">
		<div class="dataTables_empty"></div>
		<a href="<?=cn("packages/index/add")?>" class="btn btn-primary"><?=lang("add_new")?></a>
	</div>
</div>