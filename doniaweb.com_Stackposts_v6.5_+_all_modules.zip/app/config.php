<?php
define('DB_HOST', 'localhost');
define('DB_USER', '');
define('DB_PASS', '');
define('DB_NAME', '');
define('TIMEZONE', 'Pacific/Niue');
define('ENCRYPTION_KEY', '8de0682e4b3633865bc7ccbcdc29defb');
